## Model tests

Scripts for testing model simulations.
