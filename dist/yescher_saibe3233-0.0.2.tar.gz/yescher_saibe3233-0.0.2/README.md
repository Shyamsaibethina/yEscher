# yEscher

This is a simple package that allows users to run gene knockouts on S. cerevisae and visualize them using Escher.