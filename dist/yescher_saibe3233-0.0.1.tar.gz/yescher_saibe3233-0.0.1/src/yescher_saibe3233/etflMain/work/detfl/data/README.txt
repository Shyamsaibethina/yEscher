These files were obtained from https://github.com/QTB-HHU/daphne_ecoli-diauxie/blob/master/ecoli/
Publication:
Succurro, Antonella, Daniel Segre, and Oliver Ebenhöh. "Emergent subpopulation behavior uncovered with a community dynamic metabolic model of Escherichia coli diauxic growth." MSystems 4.1 (2019): e00230-18.
DOI: 10.1128/mSystems.00230-18

They are data obtained from 
Enjalbert, Brice, et al. "Acetate exposure determines the diauxic behavior of Escherichia coli during the glucose-acetate transition." Journal of bacteriology 197.19 (2015): 3173-3181.
DOI: 10.1128/JB.00128-15

and digitized from
Varma, Amit, and Bernhard O. Palsson. "Stoichiometric flux balance models quantitatively predict growth and metabolic by-product secretion in wild-type Escherichia coli W3110." Appl. Environ. Microbiol. 60.10 (1994): 3724-3731.
