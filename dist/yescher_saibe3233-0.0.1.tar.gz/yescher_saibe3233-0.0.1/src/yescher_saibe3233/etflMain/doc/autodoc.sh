rm etfl.rst etfl.*.rst
sphinx-apidoc -o . ../etfl
rm modules.rst
